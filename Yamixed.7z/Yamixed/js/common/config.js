CONFIG = (function(){
  
  return {
  	 SUPPORT : 'lmj3648xm@hotmail.com',
     host : 'http://www.yamixed.com',
     basicAuth : {
     	username : 'tagar48MZ',
     	password : 'xiaXue8812Lmj'
     },
     url : {
     	getCategories : '/rest/api/v1/category/all',
     	newMix : '/rest/api/v1/mix/new'
     }
  };

})();